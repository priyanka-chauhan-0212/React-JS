import fileName from './helper.js';
export const libName = 'es6-lib';

const login = () => {
    console.log(fileName);
};

export default login;

// console.log(libName);
