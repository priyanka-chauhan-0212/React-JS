import "./App.css";
import UserTable from "./views/UsersTable";

function App() {
  return (
    <div className="">
      <UserTable />
    </div>
  );
}

export default App;
