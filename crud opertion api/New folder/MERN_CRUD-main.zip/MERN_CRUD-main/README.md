# MERN_CRUD
MERN_CRUD

Steps to run crud app
- Go to backend folder
- use npm i / npm i --force
- npm start (it will run your backend server on port 8000 by default you can change it from config.env file)

and

- Go to frontend folder
- use npm i / npm i --force
- npm start (it will run your frontend on port 3000 by default)

Now you are ready to go.
hit http://localhost:3000 in your browser to view crud app.
